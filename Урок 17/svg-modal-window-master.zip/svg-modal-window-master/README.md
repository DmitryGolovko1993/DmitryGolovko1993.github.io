SVG Modal Window
=========

A simple modal window with an animated SVG background.

[Article on CodyHouse](http://codyhouse.co/?p=891)

[Demo](http://codyhouse.co/demo/svg-modal-window/index.html)
 
[Terms](http://codyhouse.co/terms/)
